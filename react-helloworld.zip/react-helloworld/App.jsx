import React from 'react';

class App extends React.Component {
	constructor(props) {
    super(props)
    this.displayValues = this.displayValues.bind(this)
  }
  displayValues() {
    alert("item is clicked");
  }
	
  render() {
	  var obj = [{
					"id": 1,
		"icon": "icon",
		"date": "2017-05-01",
		"daysAgo": "330",
		"campaign": "Test Whatsapp",
		"viewPrice": "222"
	},
	{
					"id": 2,
		"icon": "icon",
		"date": "2017-05-01",
		"daysAgo": "330",
		"campaign": "ADFADFDF",
		"viewPrice": "710"
	},
		{
					"id": 3,
		"icon": "icon",
		"date": "2017-05-01",
		"daysAgo": "330",
		"campaign": "super jesels quest",
		"viewPrice": "710"
	},
		{
					"id": 4,
		"icon": "icon",
		"date": "2017-05-01",
		"daysAgo": "330",
		"campaign": "mole slaayer",
		"viewPrice": "713"
	},
		{
			"id": 4,
		"icon": "icon",
		"date": "2017-05-01",
		"daysAgo": "330",
		"campaign": "mancala mix",
		"viewPrice": "713"
	}
];
    return (
   <table className="zui-table">
   <caption>Manage <b>Campaigns</b></caption>
    <thead>
        <tr>
            <th>DATE</th>
            <th>CAMPAIGN</th>
            <th>VIEW</th>
            <th>ACTIONS</th>
        </tr>
    </thead>
    <tbody>
            {obj.map((obj,i) => {
              return (
                <tr key={i}>
                 <td>{obj.date} <br/> {obj.daysAgo} days ago</td>
				 <td>{obj.campaign}</td>
				 <td>{obj.viewPrice}</td>
				 <td id={obj.id} className="icon" onClick={this.displayValuess}>{obj.icon} {obj.icon} {obj.icon}</td>
                </tr>
              );
            })}
        
		
    </tbody>
</table>
    );
  }
}

export default App;
